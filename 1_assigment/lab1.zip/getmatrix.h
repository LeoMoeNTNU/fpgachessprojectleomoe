#ifndef GETMATRIX_H
#define GETMATRIX_H

#include "list_types.h"


list_t getmatrix(const char * filename);

#endif