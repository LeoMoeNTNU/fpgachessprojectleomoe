#include "list_types.h"
int * basic_valid(list_t matrix);